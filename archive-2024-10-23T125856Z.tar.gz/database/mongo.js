const { MongoClient } = require('mongodb');

const uri = process.env.MONGO_URI; // Your MongoDB connection string
let db; // Initialize db variable
let client; // Initialize client variable

// Connect to MongoDB
async function connect() {
    if (db) return db; // Return the existing db connection

    try {
        client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
        db = client.db('spark'); // Replace with your database name
        console.log('Connected to MongoDB');
        return db; // Return the connected db instance
    } catch (error) {
        console.error('Failed to connect to MongoDB:', error);
        throw error; // Re-throw the error to handle it where connect() is called
    }
}

// Close the connection (optional)
async function closeConnection() {
    if (client) {
        await client.close();
        console.log('MongoDB connection closed');
    }
}

module.exports = { connect, closeConnection };
