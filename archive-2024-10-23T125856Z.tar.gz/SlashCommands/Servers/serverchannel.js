const { CommandInteraction, MessageEmbed } = require('discord.js');

module.exports = {
    name: 'serverchannel',
    description: '📡 | Displays a list of all channels in the server.',
    type: 'CHAT_INPUT',

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        try {
            if (!interaction.replied && !interaction.deferred) {
                await interaction.deferReply({ ephemeral: false });
            }

            const guild = interaction.guild;

            // Create an embed for displaying channels
            const embed = new MessageEmbed()
                .setColor('#3498db')
                .setTitle(`📋 Channels in **${guild.name}**`)
                .setDescription('Here is a list of all channels in this server:')
                .setTimestamp();

            const textChannels = [];
            const voiceChannels = [];
            const categoryChannels = [];

            guild.channels.cache.forEach(channel => {
                if (channel.type === 'GUILD_TEXT') {
                    textChannels.push(`🔹 ${channel.name} (ID: ${channel.id})`);
                } else if (channel.type === 'GUILD_VOICE') {
                    voiceChannels.push(`🔊 ${channel.name} (ID: ${channel.id})`);
                } else if (channel.type === 'GUILD_CATEGORY') {
                    categoryChannels.push(`📂 ${channel.name} (ID: ${channel.id})`);
                }
            });

            // Add channels to the embed
            const fields = [];
            if (categoryChannels.length) {
                fields.push({ name: '📂 Categories', value: categoryChannels.join('\n'), inline: false });
            }
            if (textChannels.length) {
                // Split text channels if they exceed 1024 characters
                let textChannelField = '';
                textChannels.forEach(channel => {
                    if ((textChannelField + channel + '\n').length > 1024) {
                        fields.push({ name: '🔹 Text Channels', value: textChannelField.trim(), inline: false });
                        textChannelField = channel + '\n'; // Start a new field
                    } else {
                        textChannelField += channel + '\n';
                    }
                });
                if (textChannelField) {
                    fields.push({ name: '🔹 Text Channels', value: textChannelField.trim(), inline: false });
                }
            }
            if (voiceChannels.length) {
                // Split voice channels if they exceed 1024 characters
                let voiceChannelField = '';
                voiceChannels.forEach(channel => {
                    if ((voiceChannelField + channel + '\n').length > 1024) {
                        fields.push({ name: '🔊 Voice Channels', value: voiceChannelField.trim(), inline: false });
                        voiceChannelField = channel + '\n'; // Start a new field
                    } else {
                        voiceChannelField += channel + '\n';
                    }
                });
                if (voiceChannelField) {
                    fields.push({ name: '🔊 Voice Channels', value: voiceChannelField.trim(), inline: false });
                }
            }

            // If no channels found
            if (!textChannels.length && !voiceChannels.length && !categoryChannels.length) {
                embed.setDescription('No channels found in this server.');
            } else {
                embed.addFields(fields); // Add the fields to the embed
            }

            // Send the embed as a reply
            await interaction.followUp({ embeds: [embed] });

        } catch (error) {
            console.error('Error in /serverchannel command:', error);
            await interaction.followUp({ content: '⚠️ There was an error while retrieving the channel list.', ephemeral: true });
        }
    }
};
