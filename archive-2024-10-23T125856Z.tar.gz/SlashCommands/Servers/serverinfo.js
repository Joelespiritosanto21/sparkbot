const { CommandInteraction, MessageEmbed } = require('discord.js');

module.exports = {
    name: 'serverinfo',
    description: '📊 | Displays information about the server.',
    type: 'CHAT_INPUT', // This indicates that it's a slash command

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        try {
            // Check if interaction has already been replied to or deferred
            if (!interaction.replied && !interaction.deferred) {
                await interaction.deferReply({ ephemeral: false });
            }

            const guild = interaction.guild; // Get the guild (server) info

            // Get server icon
            const serverIcon = guild.iconURL({ dynamic: true, size: 512 });

            // Calculate server creation date
            const createdTimestamp = Math.floor(guild.createdTimestamp / 1000);

            // Get total members
            const totalMembers = guild.memberCount;

            // Get online members (filter for users who are not bots and are online)
            const onlineMembers = guild.members.cache.filter(member => !member.user.bot && member.presence?.status === 'online').size;

            // Count of channels
            const textChannels = guild.channels.cache.filter(channel => channel.type === 'GUILD_TEXT').size;
            const voiceChannels = guild.channels.cache.filter(channel => channel.type === 'GUILD_VOICE').size;
            const totalChannels = textChannels + voiceChannels;

            // Get server owner
            const owner = await guild.fetchOwner();

            // Get the total number of roles
            const totalRoles = guild.roles.cache.size;

            // Get the server's boost level and booster count
            const boostLevel = guild.premiumTier ? `Level ${guild.premiumTier}` : 'None';
            const boostCount = guild.premiumSubscriptionCount || 0;

            // Create the embed to display server information
            const serverInfoEmbed = new MessageEmbed()
                .setColor('#3498db') // Nice blue color
                .setTitle(`🌍 Server Information`)
                .setThumbnail(serverIcon) // Server icon
                .setDescription(`Here's a summary of **${guild.name}**:`)
                .addFields(
                    { name: '📛 **Server Name**', value: guild.name, inline: true },
                    { name: '🆔 **Server ID**', value: guild.id, inline: true },
                    { name: '👑 **Owner**', value: `${owner.user.tag} (${owner.user.id})`, inline: true },
                    { name: '🌍 **Region**', value: guild.preferredLocale || 'Not set', inline: true },
                    { name: '📅 **Created On**', value: `<t:${createdTimestamp}:R>`, inline: true }, // Relative timestamp
                    { name: '👥 **Total Members**', value: `${totalMembers} members`, inline: true },
                    { name: '🟢 **Online Members**', value: `${onlineMembers} members`, inline: true },
                    { name: '📢 **Channels**', value: `Text: ${textChannels}\nVoice: ${voiceChannels}\nTotal: ${totalChannels}`, inline: true },
                    { name: '📜 **Total Roles**', value: `${totalRoles} roles`, inline: true },
                    { name: '🚀 **Boost Level**', value: `${boostLevel}`, inline: true },
                    { name: '💎 **Boosters**', value: `${boostCount} boosters`, inline: true },
                )
                .setFooter({ text: `Server Information`, iconURL: serverIcon })
                .setTimestamp();

            // Send the embed as a reply
            await interaction.followUp({ embeds: [serverInfoEmbed] });

        } catch (error) {
            console.error('Error in /serverinfo command:', error);
            await interaction.followUp({ content: '⚠️ There was an error while retrieving server information.', ephemeral: true });
        }
    }
};
