const { Client, CommandInteraction, MessageEmbed, MessageActionRow, MessageButton } = require("discord.js");
const ec = require("../../settings/embed");
const { connect } = require('../../database/mongo'); // Ensure this path is correct

const COLLECTION_NAME = 'giveaways';

module.exports = {
    name: 'giveaway',
    description: '🎉 | Start a giveaway in your server with custom title, description, and join/leave buttons.',
    category: 'Fun',
    userPermissions: ['MANAGE_MESSAGES'],
    type: 'CHAT_INPUT',
    ownerOnly: false,
    options: [
        {
            name: 'title',
            type: 'STRING',
            description: 'Title of the giveaway',
            required: true
        },
        {
            name: 'description',
            type: 'STRING',
            description: 'Description of the giveaway',
            required: true
        },
        {
            name: 'duration',
            type: 'STRING',
            description: 'Duration of the giveaway (e.g., 1h, 1d)',
            required: true
        },
        {
            name: 'prize',
            type: 'STRING',
            description: 'Prize for the giveaway (e.g., $20 gift card)',
            required: true
        },
        {
            name: 'winners',
            type: 'INTEGER',
            description: 'Number of winners (default is 1)',
            required: true
        }
    ],

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        await interaction.deferReply({ ephemeral: false }).catch(() => {}); // Defer the reply

        const title = interaction.options.getString('title');
        const description = interaction.options.getString('description');
        const duration = interaction.options.getString('duration');
        const prize = interaction.options.getString('prize');
        const winners = interaction.options.getInteger('winners') || 1;  // Default winners is 1

        // Convert duration to milliseconds
        const durationMs = parseDuration(duration);
        if (!durationMs) {
            return interaction.followUp({ content: 'Invalid duration format! Use (1m, 1h, 1d)', ephemeral: true });
        }

        const giveawayEmbed = new MessageEmbed()
            .setTitle(title)
            .setDescription(description)
            .addFields(
                { name: 'Prize', value: `🎁 **${prize}**` },
                { name: 'Duration', value: `⏳ **${duration}**` },
                { name: 'Number of Winners', value: `👑 **${winners}**` }
            )
            .setFooter({ text: 'Click "Join" to participate or "Leave" to opt-out.' })
            .setColor(ec.color)
            .setTimestamp(Date.now() + durationMs);

        let totalParticipants = 0; // Track the total number of participants
        const participants = new Set();  // Store users who have joined the giveaway

        // Function to update the buttons dynamically with total participants
        const getUpdatedButtons = () => {
            return new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('join_giveaway')
                        .setLabel(`🎉 Join (${totalParticipants})`) // Display the total participants
                        .setStyle('SUCCESS'),
                    new MessageButton()
                        .setCustomId('leave_giveaway')
                        .setLabel('❌ Leave')
                        .setStyle('DANGER')
                );
        };

        // Send the giveaway message with buttons
        const giveawayMessage = await interaction.followUp({
            embeds: [giveawayEmbed],
            components: [getUpdatedButtons()],
            fetchReply: true
        });

        // Connect to MongoDB
        const db = await connect(); // Get the database connection
        const giveawaysCollection = db.collection(COLLECTION_NAME);

        // Save the giveaway details to MongoDB
        await giveawaysCollection.insertOne({
            guildId: interaction.guild.id,
            messageId: giveawayMessage.id,
            title,
            description,
            prize,
            duration: durationMs,
            winners,
            participants: [],
            createdAt: new Date()
        });

        const collector = giveawayMessage.createMessageComponentCollector({ time: durationMs });

        collector.on('collect', async (buttonInteraction) => {
            // Ensure the interaction is for this message
            if (!buttonInteraction.isButton()) return;

            if (buttonInteraction.customId === 'join_giveaway') {
                if (!participants.has(buttonInteraction.user.id)) {
                    participants.add(buttonInteraction.user.id);
                    totalParticipants++; // Increment total participants count
                    await buttonInteraction.reply({ content: `You have joined the giveaway! 🎉 Total participants: ${totalParticipants}`, ephemeral: true });

                    // Update the participants in MongoDB
                    await giveawaysCollection.updateOne(
                        { messageId: giveawayMessage.id },
                        { $addToSet: { participants: buttonInteraction.user.id } }
                    );
                } else {
                    await buttonInteraction.reply({ content: `You are already in the giveaway! 🎉 Total participants: ${totalParticipants}`, ephemeral: true });
                }
            } else if (buttonInteraction.customId === 'leave_giveaway') {
                if (participants.has(buttonInteraction.user.id)) {
                    participants.delete(buttonInteraction.user.id);
                    totalParticipants--; // Decrement total participants count
                    await buttonInteraction.reply({ content: 'You have left the giveaway! 😞', ephemeral: true });

                    // Remove the user from participants in MongoDB
                    await giveawaysCollection.updateOne(
                        { messageId: giveawayMessage.id },
                        { $pull: { participants: buttonInteraction.user.id } }
                    );
                } else {
                    await buttonInteraction.reply({ content: 'You are not part of the giveaway!', ephemeral: true });
                }
            }

            // Update the buttons to reflect the new participant count
            await giveawayMessage.edit({ components: [getUpdatedButtons()] });
        });

        collector.on('end', async () => {
            // Ensure the message exists
            if (!giveawayMessage) return;

            if (participants.size === 0) {
                return interaction.channel.send('No valid entries for the giveaway.');
            }

            const winnerIds = Array.from(participants).sort(() => Math.random() - 0.5).slice(0, winners);
            const winnersList = winnerIds.map(id => `<@${id}>`).join(', ');

            // Send the winner announcement
            interaction.channel.send(`🎉 Congratulations to the winner(s): ${winnersList}! You won **${prize}**!`);

            // Optionally, remove the giveaway from the database after it ends
            await giveawaysCollection.deleteOne({ messageId: giveawayMessage.id });
        });
    }
};

/**
 * @param {string} str 
 * @returns {number|null} milliseconds
 */
function parseDuration(str) {
    const timeUnits = {
        s: 1000,
        m: 60 * 1000,
        h: 60 * 60 * 1000,
        d: 24 * 60 * 60 * 1000
    };

    const match = str.match(/^(\d+)([smhd])$/);
    if (!match) return null;

    const value = parseInt(match[1], 10);
    const unit = match[2];

    if (timeUnits[unit]) {
        return value * timeUnits[unit];
    } else {
        return null;
    }
}
