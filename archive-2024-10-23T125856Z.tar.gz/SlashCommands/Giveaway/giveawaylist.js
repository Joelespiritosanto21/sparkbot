const { Client, CommandInteraction, MessageEmbed } = require('discord.js');
const ec = require("../../settings/embed");
const { connect } = require('../../database/mongo'); // Adjusted path

module.exports = {
    name: 'giveawaylist',
    description: '📜 | List all ongoing giveaways in the server.',
    category: 'Giveaway',
    userPermissions: ['MANAGE_MESSAGES'],
    type: 'CHAT_INPUT',

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        // Defer the reply
        await interaction.deferReply({ ephemeral: false }).catch(() => {});

        // Connect to MongoDB
        const db = await connect();

        // Fetch ongoing giveaways from the database
        const giveaways = await db.collection('giveaways').find({ guildId: interaction.guild.id }).toArray();

        if (giveaways.length === 0) {
            return interaction.followUp({ content: 'There are currently no ongoing giveaways.', ephemeral: true });
        }

        const giveawayListEmbed = new MessageEmbed()
            .setTitle('Ongoing Giveaways')
            .setColor(ec.color)
            .setFooter({ text: 'Use /giveaway reroll <giveaway_id> to reroll a giveaway.' });

        giveaways.forEach(giveaway => {
            giveawayListEmbed.addField(`Giveaway ID: ${giveaway._id}`, `Title: ${giveaway.title}\nWinners: ${giveaway.winners}`);
        });

        await interaction.followUp({ embeds: [giveawayListEmbed] });
    }
};
