const { Client, CommandInteraction, MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu } = require('discord.js');

// Developer details
const developers = [
    {
        name: 'NeoServer_',
        title: 'Founder & Lead Developer',
        description: 'Hi there! I\'m NeoServer_, the Founder and Lead Developer of SparkBot. I manage the core functionalities and improvements of the bot.',
        emoji: '👑',
    },
    {
        name: 'PhxDominicToretto',
        title: 'Security Manager',
        description: 'Hello! I\'m PhxDominicToretto, the Security Manager for SparkBot, responsible for maintaining the security and integrity of the bot and its users.',
        emoji: '🛡️',
    },
    {
        name: 'QntmLnx',
        title: 'Core Developer',
        description: 'Hey! I\'m QntmLnx, a Core Developer of SparkBot. I work on the essential features and improvements of the bot.',
        emoji: '💻',
    }
];

module.exports = {
    name: 'developers',
    description: 'Shows information about the developers of SparkBot.',
    userPermissions: [], // No special permissions required
    type: 'CHAT_INPUT',
    options: [], // No options needed for this command

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        try {
            // Function to create the developer embed
            const createDeveloperEmbed = (index) => {
                const developer = developers[index];
                return new MessageEmbed()
                    .setColor('#3498db')
                    .setTitle(`${developer.emoji} ${developer.name} - ${developer.title}`)
                    .setDescription(developer.description)
                    .setFooter({ text: `Developer ${index + 1} of ${developers.length}`, iconURL: interaction.guild.iconURL() })
                    .setTimestamp();
            };

            // Create the initial embed for the first developer
            let currentIndex = 0;
            const initialEmbed = createDeveloperEmbed(currentIndex);

            // Create buttons for navigation and the "About" button
            const buttons = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setCustomId('prev_developer')
                        .setLabel('Previous')
                        .setStyle('PRIMARY')
                        .setDisabled(true), // Disabled for the first developer
                    new MessageButton()
                        .setCustomId('next_developer')
                        .setLabel('Next')
                        .setStyle('PRIMARY')
                        .setDisabled(developers.length === 1), // Disabled if only one developer
                    new MessageButton()
                        .setLabel('About')
                        .setStyle('LINK') // Link button type
                        .setURL('https://www.spark-bot.xyz/developers.html') // Replace with your actual "About" URL
                );

            // Create select menu for jumping to developers
            const developerSelectMenu = new MessageSelectMenu()
                .setCustomId('developer_select')
                .setPlaceholder('Select a developer')
                .addOptions(
                    developers.map((dev, index) => ({
                        label: dev.name,
                        value: index.toString(), // Use the index as value for easy navigation
                        description: dev.title,
                        emoji: dev.emoji
                    }))
                );

            // Action row for select menu
            const selectMenuRow = new MessageActionRow().addComponents(developerSelectMenu);

            // Send the initial embed with buttons and select menu
            await interaction.followUp({ 
                embeds: [initialEmbed], 
                components: [buttons, selectMenuRow], 
                ephemeral: true 
            });

            // Collector for button clicks and select menu interaction
            const collector = interaction.channel.createMessageComponentCollector({ time: 60000 }); // Active for 1 minute

            collector.on('collect', async (i) => {
                // Check if the interaction was from the same user
                if (i.user.id !== interaction.user.id) {
                    return i.reply({ content: 'This interaction is not for you!', ephemeral: true });
                }

                // Handle button interaction
                if (i.customId === 'next_developer') {
                    currentIndex += 1;
                } else if (i.customId === 'prev_developer') {
                    currentIndex -= 1;
                } else if (i.customId === 'developer_select') {
                    currentIndex = parseInt(i.values[0]); // Get the selected developer index
                }

                // Update the embed with the new developer info
                const updatedEmbed = createDeveloperEmbed(currentIndex);

                // Enable/disable buttons based on current index
                buttons.components[0].setDisabled(currentIndex === 0);
                buttons.components[1].setDisabled(currentIndex === developers.length - 1);

                // Update the interaction with the new developer info and updated buttons
                await i.update({ embeds: [updatedEmbed], components: [buttons, selectMenuRow], ephemeral: true });
            });

            collector.on('end', collected => {
                // If the collector ended (e.g., timeout), disable all buttons and select menu
                buttons.components.forEach(button => button.setDisabled(true));
                developerSelectMenu.setDisabled(true);

                // Edit the original interaction to disable components after the collector ends
                interaction.editReply({ components: [buttons, selectMenuRow] });
            });

        } catch (error) {
            console.error('Error in /developers command:', error);
            await interaction.followUp({ content: 'There was an error while retrieving the developer information.' });
        }
    }
};
