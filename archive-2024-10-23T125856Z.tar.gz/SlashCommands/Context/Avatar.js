const { Client, CommandInteraction, MessageEmbed } = require("discord.js");
const ec = require("../../settings/embed");

module.exports = {
    name: 'avatar',
    description: '📸 | Get a user\'s avatar with a slash command.',
    category: 'Utility',
    userPermissions: [],
    type: 'CHAT_INPUT',
    options: [
        {
            name: 'user',
            type: 'USER',
            description: 'The user whose avatar you want to display',
            required: false // Optional, defaults to the command invoker's avatar if not provided
        }
    ],

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        try {
            // Get the targeted user from the interaction, or use the interaction user if none provided
            const targetUser = interaction.options.getUser('user') || interaction.user;

            // Create an embed for displaying the user's avatar
            const avatarEmbed = new MessageEmbed()
                .setTitle(`${targetUser.username}'s Avatar`)
                .setColor(ec.color) // Use the color from your settings
                .setFooter({ text: ec.footer }) // Use the footer from your settings
                .setImage(targetUser.displayAvatarURL({ dynamic: true, size: 512 })) // Dynamic avatar with high resolution
                .setTimestamp();

            // Send the embed as a reply in the interaction
            await interaction.followUp({
                content: `${targetUser.tag}'s Avatar`,
                embeds: [avatarEmbed],
                ephemeral: false // Makes the result visible to everyone
            });

        } catch (error) {
            console.error('Error fetching avatar:', error);
            await interaction.followUp({ content: 'There was an error fetching the avatar.', ephemeral: true });
        }
    },
};
