const { Client, CommandInteraction, MessageEmbed, MessageActionRow, MessageButton, MessageSelectMenu } = require('discord.js');
const ec = require("../../settings/embed"); // Assuming this is where you have your embed settings

const categories = [
    ["Info", "📖", "Learn about the bot"],
    ["Voting", "✅", "Vote for SparkBot and claim rewards!"],
    ["Economy", "💰", "Manage your server's economy with economic features."],
    ["Utility", "🛠️", "Enhance server functionality with versatile commands."],
    ["Server", "🧰", "Get information about your server."],
    ["Giveaway", "🎉", "Start giveaways to enhance server activity!"],
    ["Logger", "📜", "Manage and monitor server activities."],
    ["Music", "🎶", "Control music playback in your server."],
    ["Setup", "⚙️", "Configure the bot and manage server settings easily."]
];

const commands = {
    info: ["ping", "help", "invite", "developers", "uptime", "stats", "info support", "info website"],
    voting: ["vote link", "vote count", "vote rewards", "vote claim"],
    economy: ["credits", "daily", "richest"],
    utility: ["user info", "user permissions", "user roles", "messages leaderboard", "messages count", "role add", "role position", "role remove"],
    giveaway: ["giveaway start", "giveaway end", "giveaway reroll"],
    music: ["coming soon"],
    logger: ["coming soon"],
    server: ["server info", "server channel", "server roles", "server icon", "server invite", "server banner"],
};

module.exports = {
    name: 'help',
    description: 'Displays help commands and categories.',
    userPermissions: [], // No permissions required for help
    type: 'CHAT_INPUT',
    options: [], // No options needed for the help command

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     * @param {String[]} args 
     */
    run: async (client, interaction) => {
        try {
            // Create the initial help embed
            const helpEmbed = new MessageEmbed()
                .setColor('#3498db') // Blue color for the embed
                .setTitle('✨ Help Menu ✨')
                .setDescription('Please select a category from the menu below to see the commands available in that category.')
                .setFooter({ text: 'Happy chatting!', iconURL: interaction.guild.iconURL() })
                .setTimestamp();

            // Create a select menu for category selection
            const categorySelectMenu = new MessageSelectMenu()
                .setCustomId('help_category_select')
                .setPlaceholder('Select a category')
                .addOptions(
                    categories.map(cat => ({
                        label: cat[0],
                        value: cat[0].toLowerCase(), // e.g., "info", "backup", etc.
                        description: cat[2], // The description
                        emoji: cat[1] // The emoji
                    }))
                );

            // Create action rows for support and invite buttons
            const row1 = new MessageActionRow()
                .addComponents(
                    new MessageButton()
                        .setLabel('Support')
                        .setStyle('LINK')
                        .setURL('https://discord.gg/MM57suwq6Z'),
                    new MessageButton()
                        .setLabel('Invite')
                        .setStyle('LINK')
                        .setURL(`https://discord.com/oauth2/authorize?client_id=${client.user.id}&permissions=2184260928&scope=bot%20applications.commands`)
                );

            // Create an action row to hold the select menu
            const row2 = new MessageActionRow().addComponents(categorySelectMenu);

            // Send the initial help embed with the select menu and buttons
            await interaction.followUp({ embeds: [helpEmbed], components: [row2, row1], ephemeral: true });

            // Create a collector to handle the selection
            const filter = i => i.customId === 'help_category_select' && i.user.id === interaction.user.id;
            const collector = interaction.channel.createMessageComponentCollector({ filter, time: 30000 }); // Collector timeout after 30 seconds

            collector.on('collect', async (i) => {
                const selectedCategory = i.values[0]; // Get the selected value (e.g., "info")

                // Get the commands for the selected category
                const categoryCommands = commands[selectedCategory]; // Retrieve commands based on selected category

                // Create an embed for the selected category commands
                const categoryEmbed = new MessageEmbed()
                    .setColor('#3498db')
                    .setTitle(`📂 ${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)} Commands`)
                    .setDescription(`Here are the commands available in the **${selectedCategory.charAt(0).toUpperCase() + selectedCategory.slice(1)}** category:\n\n` +
                        `\`\`\`/${categoryCommands.join('\n/')}\`\`\``)
                    .setFooter({ text: 'Use / to select a command!', iconURL: interaction.guild.iconURL() })
                    .setTimestamp();

                // Update the interaction with the category commands and keep the select menu
                await i.update({ embeds: [categoryEmbed], components: [row2, row1], ephemeral: true }); // Update the interaction with the category commands
            });

            collector.on('end', collected => {
                // If the collector ended (e.g., due to timeout), disable the select menu
                if (collected.size === 0) {
                    interaction.followUp({ content: 'You did not select any category in time!', ephemeral: true });
                }
            });

        } catch (error) {
            console.error('Error in /help command:', error);
            await interaction.followUp({ content: 'There was an error while retrieving the help information.' });
        }
    }
};
