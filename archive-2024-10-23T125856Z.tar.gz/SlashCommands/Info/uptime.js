const { MessageEmbed } = require('discord.js');

module.exports = {
    name: 'uptime',
    description: 'Displays how long the bot has been running.',
    userPermissions: [], // No permissions required for uptime
    type: 'CHAT_INPUT',
    options: [], // No options needed for the uptime command

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     * @param {String[]} args 
     */
    run: async (client, interaction, args) => {
        try {
            // Get the bot's uptime in milliseconds
            const totalUptime = client.uptime;

            // Calculate time components
            const seconds = Math.floor((totalUptime / 1000) % 60);
            const minutes = Math.floor((totalUptime / (1000 * 60)) % 60);
            const hours = Math.floor((totalUptime / (1000 * 60 * 60)) % 24);
            const days = Math.floor(totalUptime / (1000 * 60 * 60 * 24));

            // Format the uptime as a string
            const uptimeString = `${days}d ${hours}h ${minutes}m ${seconds}s`;

            // Create an embed to display the uptime
            const uptimeEmbed = new MessageEmbed()
                .setColor('#00FF00') // Green color for the embed
                .setTitle('⏰ Bot Uptime ⏰')
                .setDescription(`The bot has been running for: **${uptimeString}**`)
                .setFooter({ text: interaction.guild.name, iconURL: interaction.guild.iconURL() })
                .setTimestamp();

            // Send the embed as a follow-up to the deferred reply
            await interaction.followUp({ embeds: [uptimeEmbed], ephemeral: true });
        } catch (error) {
            console.error('Error in /uptime command:', error);
            await interaction.followUp({ content: 'There was an error while retrieving the bot uptime.' });
        }
    }
};
