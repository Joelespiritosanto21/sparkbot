const { CommandInteraction, MessageEmbed } = require('discord.js');
const os = require('os'); // To get system-related info

module.exports = {
    name: 'info',
    description: '📊 | Displays information about the bot and its commands.',
    type: 'CHAT_INPUT', // Slash command

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        try {
            // Bot's uptime (in hours, minutes, seconds)
            const totalSeconds = (client.uptime / 1000);
            const hours = Math.floor(totalSeconds / 3600);
            const minutes = Math.floor((totalSeconds % 3600) / 60);
            const seconds = Math.floor(totalSeconds % 60);

            // Memory usage and platform info
            const memoryUsage = (process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2); // in MB
            const platform = os.platform();
            const architecture = os.arch();

            // Create an embed to display the bot's information
            const infoEmbed = new MessageEmbed()
                .setColor('#2ecc71') // A nice green color for the embed
                .setTitle('🤖 Bot Information')
                .setThumbnail(client.user.displayAvatarURL({ dynamic: true, size: 512 })) // High-res dynamic avatar of the bot
                .addFields(
                    { name: '📛 **Bot Name**', value: client.user.tag, inline: true },
                    { name: '🆔 **Bot ID**', value: client.user.id, inline: true },
                    { name: '⏳ **Uptime**', value: `${hours}h ${minutes}m ${seconds}s`, inline: true }, // Bot's uptime
                    { name: '🖥️ **Platform**', value: `\`${platform} ${architecture}\``, inline: true },
                    { name: '💾 **Memory Usage**', value: `\`${memoryUsage} MB\``, inline: true },
                    { name: '📅 **Joined Discord On**', value: `<t:${Math.floor(client.user.createdTimestamp / 1000)}:R>`, inline: true }, // Relative timestamp
                )
                .setFooter({ text: `Use /help to see all commands!`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            // Commands info: Refer users to the /help command for more details
            const availableCommands = '/help'; // Directing users to the help command
            infoEmbed.addFields(
                { name: '🛠 **Available Commands**', value: `Use ${availableCommands} to see all commands!`, inline: false },
            );

            // Send the embed as a reply
            await interaction.followUp({ embeds: [infoEmbed], ephemeral: true });
        } catch (error) {
            console.error('Error in /info command:', error);
            await interaction.followUp({ content: '⚠️ There was an error while retrieving bot information.', ephemeral: true });
        }
    }
};
