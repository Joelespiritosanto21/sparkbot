const client = require("../../index");
const set = require("../../settings/settings.js");
const chalk = require('chalk');
const db = require('quick.db');
console.clear();

client.on('ready', async () => {
  const activities = [
    { name: `${client.users.cache.size} Users`, type: "STREAMING", url: "https://www.twitch.tv/" },
    { name: `${client.guilds.cache.size} Guilds`, type: "STREAMING", url: "https://www.twitch.tv/" },
    { name: "With /help", type: "STREAMING", url: "https://www.twitch.tv/" },
    { name: "With NeoServer & qntmlnx", type: "STREAMING", url: "https://www.twitch.tv/" },
  ];

  let activity = 0;

  client.user.setPresence({ status: "sleep", activity: activities[0] });

  setInterval(() => {
    if (activity === activities.length) activity = 0;
    client.user.setActivity(activities[activity]);
    activity++;
  }, 40000);

  console.log(chalk.greenBright(`\n╔═════════════════════════════════════════════╗`));
  console.log(chalk.greenBright(`║                                             ║`));
  console.log(chalk.greenBright(`║             Spark-bot is alive!             ║`));
  console.log(chalk.greenBright(`║                Made by                      ║`));
  console.log(chalk.greenBright(`║             neoserver & qntmlnx!            ║`));
  console.log(chalk.greenBright(`║                                             ║`));
  console.log(chalk.greenBright(`╚═════════════════════════════════════════════╝\n`));
  
});
