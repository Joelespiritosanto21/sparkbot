const { Client, Collection, MessageEmbed } = require("discord.js");
const fs = require('fs');
const mongoose = require('mongoose');
require('dotenv').config();

const client = new Client({
    intents: [
        "GUILDS",
        "GUILD_MESSAGES",
        "GUILD_MESSAGE_REACTIONS",
        "GUILD_MEMBERS", // Needed if you plan to access member info
        "DIRECT_MESSAGES",
        "GUILD_PRESENCES",
        "GUILD_VOICE_STATES",
        "GUILD_MESSAGE_TYPING",
        "GUILD_WEBHOOKS"
    ],
});

// Global Variables
client.commands = new Collection();
client.slashCommands = new Collection();
client.cooldowns = new Collection();

// Load handlers for commands and other features
fs.readdirSync('./handlers').forEach((handler) => {
    require(`./handlers/${handler}`)(client);
});

// Event listener for message creation
client.on('messageCreate', (message) => {
    // Ignore messages from bots
    if (message.author.bot) return;

    // Check if the message mentions the bot
    if (message.mentions.has(client.user)) {
        // Define your prefix and commands
        const prefix = 's?'; // You can replace this with a dynamic prefix from a database
        const commands = client.commands.map(cmd => `\`${cmd.name}\``).join(', ');

        // Create the embed message
        const embed = new MessageEmbed()
            .setColor('#3498db')
            .setTitle('Bot Information')
            .setDescription('Hello! Here is some information about me:')
            .addField('Prefix', prefix, true)
            .addField('Available Prefix Commands', commands || 'No commands available.', false)
            .setFooter('Use the prefix followed by a command to interact with me!')
            .setTimestamp();

        // Send the embed message
        message.channel.send({ embeds: [embed] }).catch(err => console.error('Failed to send message:', err));
    }
});

// Event listener for when the bot joins a guild
client.on('guildCreate', (guild) => {
    const channel = guild.systemChannel || guild.channels.cache.find(ch => ch.type === 'GUILD_TEXT');
    if (!channel) return; // Ensure there is a valid channel to send the message

    // Define your prefix and commands
    const prefix = '!'; // You can replace this with a dynamic prefix from a database
    const commands = client.commands.map(cmd => `\`${cmd.name}\``).join(', ');

    // Create the embed message
    const embed = new MessageEmbed()
        .setColor('#3498db')
        .setTitle(`Hello, **${guild.name}**!`) // Fixed to use backticks
        .setDescription(`Thank you for adding me to **${guild.name}**! Here’s how you can interact with me:`)
        .addField('Prefix', prefix, true)
        .addField('Available Prefix Commands', commands || 'No commands available.', false)
        .setFooter('Feel free to ping me using @' + client.user.username + ' or use slash commands!')
        .setTimestamp();

    // Send the embed message to the guild's system channel or a text channel
    channel.send({ embeds: [embed] })
        .catch(err => console.error('Failed to send message to the guild:', err)); // Catch any errors while sending the message
});

// Log in the bot using the token from environment variables
client.login(process.env.token);

// Error handling for unhandled promise rejections
process.on("unhandledRejection", error => {
    console.error("Unhandled rejection:", error);
});

// Export the client for use in other files
module.exports = client;
