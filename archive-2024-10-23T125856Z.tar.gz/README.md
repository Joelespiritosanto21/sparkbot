╭・⌬・[mention] joined the [servername]
●▬▬▬▬▬▬▬▬๑۩✰۩๑▬▬▬▬▬▬▬▬●
✰・Account created [accountcreated]
✰・Invited by [invitername]
✰・They have now [invitecount] invites
●▬▬▬▬▬▬▬▬๑۩✰۩๑▬▬▬▬▬▬▬▬●
╰・⌬・ has now [membercount] members
```
