module.exports = {

    guildName: "Spark Bot Support",
    guildID: "1281276223523389471",
    ownerName: "neoserver_.",
    ownerId: "1102137960763248731",
    guildInvite: "https://discord.gg/MM57suwq6Z",


    // private server SETTINS //
    modLogs: "",
    boosters: "",
    levelsChannel: "",
    botLogs: "",

    boosterGif: "https://imgur.com/SGArz37.gif",
    mainGif: "",
    welcome: "",
    goodbye: "",
    levelGif: "",

    botOwner: "neoserver_.",
    handlerVersion: "3.1.0",
    developers: ["neoserver_."],
    website: "https://www.spark-bot.xyz/",
    botOwnerId: "1102137960763248731",
    supportInvite: "https://discord.gg/MM57suwq6Z",
    botInvite: "https://discord.com/oauth2/authorize?client_id=1274347392858062858&permissions=8&integration_type=0&scope=bot"
}