module.exports = {
    color: "#55FF33",
    footer: "Spark Bot",
    iconURL: "",
    image: "",

    wrong: "#FF0000",
    error: "#FF8000",
    caution: "#FFFF33",
    success: "#55FF33",
    red: "#FF0000",
    blue: "#0000FF",
    pink: "#FF66E5",
    purple: "#AA00CC",
    white: "#FFFFFF",
    black: "#000000",
    yellow: "#FFFF00",
    blurple: "Blurple",
    clear: "#2e3137",
    green: "#55FF33"
} 