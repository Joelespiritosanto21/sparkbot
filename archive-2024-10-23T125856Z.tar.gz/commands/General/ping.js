const { MessageEmbed, MessageButton, MessageActionRow } = require("discord.js");
const ec = require("../../settings/embed");

module.exports = {
    name: 'ping',
    description: '🏓 | Return Bot Latencies',
    category: 'info',
    cooldown: 10,
    run: async (client, message) => {
        // Emojis for status indicators
        const circles = {
            green: "🟢",
            yellow: "🟡",
            red: "🔴"
        };

        // Calculate uptime
        let days = Math.floor(client.uptime / 86400000);
        let hours = Math.floor(client.uptime / 3600000) % 24;
        let minutes = Math.floor(client.uptime / 60000) % 60;
        let seconds = Math.floor(client.uptime / 1000) % 60;

        // Calculate latencies
        let botLatency = new Date() - message.createdAt;
        let apiLatency = client.ws.ping;

        // Create buttons
        const supportServerButton = new MessageButton()
            .setStyle('LINK')
            .setLabel('Support Server')
            .setURL('https://your-support-server-link.com'); // Replace with your support server link

        // Create the embed
        const pingEmbed = new MessageEmbed()
            .setTitle("📊 Bot Latency & Ping")
            .setColor(ec.color)
            .setThumbnail(client.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { 
                    name: "Bot Latency:", 
                    value: `${botLatency <= 200 ? circles.green : botLatency <= 400 ? circles.yellow : circles.red} ${botLatency}ms`, 
                    inline: true 
                },
                { 
                    name: "API Latency:", 
                    value: `${apiLatency <= 200 ? circles.green : apiLatency <= 400 ? circles.yellow : circles.red} ${apiLatency}ms`, 
                    inline: true 
                },
                { 
                    name: "Client Uptime:", 
                    value: `${days}d ${hours}h ${minutes}m ${seconds}s`, 
                    inline: true 
                }
            )
            .setFooter({ text: `Requested by ${message.author.tag}`, iconURL: message.author.displayAvatarURL() })
            .setTimestamp();

        // Create an action row for buttons
        const row = new MessageActionRow()
            .addComponents(supportServerButton);

        // Send the reply with the embed and button
        return message.reply({ embeds: [pingEmbed], components: [row], allowedMentions: { repliedUser: false } });
    },
};
