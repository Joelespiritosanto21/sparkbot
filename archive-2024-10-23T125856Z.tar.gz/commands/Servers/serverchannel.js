const { CommandInteraction, MessageEmbed } = require('discord.js');
const Guild = require('../../models/Guild'); // Adjust the path according to your project structure

module.exports = {
    name: 'commandchannel',
    description: '📡 | Set the command channel for the server.',
    options: [
        {
            name: 'channel',
            type: 'CHANNEL', // Ensure that the type is correct
            description: 'Select a channel for commands',
            required: true,
        },
    ],

    /**
     * @param {Client} client 
     * @param {CommandInteraction} interaction 
     */
    run: async (client, interaction) => {
        try {
            // Get the channel object from the interaction options
            const channel = interaction.options.getChannel('channel');

            // Check if the channel is valid
            if (!channel || channel.type !== 'GUILD_TEXT') {
                return interaction.reply({ content: '⚠️ Please select a valid text channel.', ephemeral: true });
            }

            const channelId = channel.id;

            // Get the guild data from the database
            let guildData = await Guild.findOne({ guildId: interaction.guild.id });

            // If the guild data doesn't exist, create a new entry
            if (!guildData) {
                guildData = new Guild({
                    guildId: interaction.guild.id,
                    prefix: '!', // You can customize this if needed
                    commands: [],
                    commandChannelId: channelId, // Initialize the command channel here
                });
            } else {
                // Update the command channel ID
                guildData.commandChannelId = channelId;
            }

            // Save the guild data
            await guildData.save();

            // Create a confirmation embed
            const embed = new MessageEmbed()
                .setColor('#2ecc71')
                .setTitle('✅ Command Channel Set!')
                .setDescription(`The command channel has been set to <#${channelId}>.`)
                .addFields(
                    { name: '🔗 Channel ID', value: channelId, inline: true }
                )
                .setFooter({ text: `Use ${guildData.prefix}help to see available commands!`, iconURL: client.user.displayAvatarURL({ dynamic: true }) })
                .setTimestamp();

            // Reply to the interaction
            await interaction.reply({ embeds: [embed], ephemeral: true });

        } catch (error) {
            console.error('Error in /commandchannel command:', error);
            await interaction.reply({ content: '⚠️ There was an error while setting the command channel.', ephemeral: true });
        }
    },
};
