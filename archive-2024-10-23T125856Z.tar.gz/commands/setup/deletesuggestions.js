const { Client, MessageEmbed } = require('discord.js');
const db = require("quick.db");

module.exports = {
    name: 'deletesuggestions',
    description: "Delete the channel for suggestions",
    category: "Settings",
    aliases: ['cc'],
    userPermissions: ["MANAGE_CHANNELS"],
    botPermissions: [],
    emoji: "🛠️",

    /**
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {
        try {
            // Delete the suggestions channel setting from the database
            db.delete(`suggestions_${message.guild.id}`);
            
            // Send a confirmation message
            message.channel.send("✅ Done! The suggestions channel has been deleted.");
        } catch (e) {
            console.error(e);
            message.reply("An error occurred while deleting the suggestions channel.");
        }
    }
};
