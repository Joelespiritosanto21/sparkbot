const db = require('quick.db');
const { MessageActionRow, MessageButton, MessageEmbed } = require("discord.js");

module.exports = {
    name: 'setup-auditlog',
    description: '🔓 | setup logs',
    userPermissions: ['ADMINISTRATOR'],

    /**
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args) => {
        // Check if the user has the required permissions
        if (!message.member.permissions.has('ADMINISTRATOR')) {
            return message.reply("You don't have permission to use this command!");
        }

        // Create the action rows for buttons
        let row = new MessageActionRow().addComponents(
            new MessageButton()
                .setLabel(`Messages Log`)
                .setCustomId(`msg`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Members Log`)
                .setCustomId(`mem`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Bans & Kicks Log`)
                .setCustomId(`ban`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Channels Log`)
                .setCustomId(`ch`)
                .setStyle(`SECONDARY`)
        );

        let row1 = new MessageActionRow().addComponents(
            new MessageButton()
                .setLabel(`Webhook Log`)
                .setCustomId(`webhook`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Voice Log`)
                .setCustomId(`voice`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Timeout Log`)
                .setCustomId(`Timeout`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Thread Log`)
                .setCustomId(`thread`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Roles Log`)
                .setCustomId(`role`)
                .setStyle(`SECONDARY`)
        );

        let row1s = new MessageActionRow().addComponents(
            new MessageButton()
                .setLabel(`Setup All Audit Log`)
                .setCustomId(`alt`)
                .setStyle(`SUCCESS`),
            new MessageButton()
                .setLabel(`Delete All Audit Log`)
                .setCustomId(`select11`)
                .setStyle(`DANGER`)
        );

        // Create the embed message
        let embed = new MessageEmbed()
            .setAuthor({ name: message.member.user.username, iconURL: message.member.user.displayAvatarURL() })
            .setTitle(`Setup Your Logs!`)
            .setDescription(`> **Choose The Log You Need And Choose The Channel For It**`)
            .setThumbnail(message.guild.iconURL() || null)
            .setTimestamp()
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() || null });

        // Send the embed with buttons
        const msg = await message.channel.send({ embeds: [embed], components: [row, row1, row1s] });

        // Disable buttons after 2 minutes
        setTimeout(() => {
            row.components.forEach(button => button.setDisabled(true));
            row1.components.forEach(button => button.setDisabled(true));
            row1s.components.forEach(button => button.setDisabled(true));

            msg.edit({ embeds: [embed], components: [row, row1, row1s] });
        }, 120000);
    }
};
