const db = require('quick.db');
const { MessageActionRow, MessageButton, MessageSelectMenu, MessageEmbed } = require("discord.js");

module.exports = {
    name: 'setup-welcome',
    description: '❎ | setup welcome',
    userPermissions: ['ADMINISTRATOR'],

    /**
     * @param {Client} client 
     * @param {Message} message 
     * @param {String[]} args 
     */
    run: async (client, message, args) => {
        // Check if the user has the required permissions
        if (!message.member.permissions.has('ADMINISTRATOR')) {
            return message.reply("You don't have permission to use this command!");
        }

        // Create the action row for buttons
        const row = new MessageActionRow().addComponents(
            new MessageButton()
                .setLabel(`Setup Channel`)
                .setCustomId(`welcomes`)
                .setStyle(`SUCCESS`),
            new MessageButton()
                .setLabel(`Setup Background`)
                .setCustomId(`welcome_app`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Setup Message`)
                .setCustomId(`message_app`)
                .setStyle(`SECONDARY`),
            new MessageButton()
                .setLabel(`Setup Color`)
                .setCustomId(`color_app`)
                .setStyle(`SECONDARY`)
        );

        // Create the action row for the select menu
        const row3 = new MessageActionRow()
            .addComponents(
                new MessageSelectMenu()
                    .setCustomId('select')
                    .setPlaceholder('Select settings')
                    .addOptions([
                        {
                            label: 'Delete Welcome Background',
                            value: 'delete_background',
                        },
                        {
                            label: 'Delete Welcome Message',
                            value: 'delete_message',
                        },
                        {
                            label: 'Delete Welcome Color',
                            value: 'delete_color',
                        },
                    ])
            );

        // Create the embed message
        const embed = new MessageEmbed()
            .setAuthor({ name: message.member.user.username, iconURL: message.member.user.displayAvatarURL() })
            .setTitle(`Setup Your Welcome!`)
            .setColor('RANDOM')
            .setImage('https://cdn.discordapp.com/attachments/1148240486981709864/1161592423433113631/My_Video.gif')
            .setDescription(`> **Choose the welcome setting you need and choose the channel assigned to it**\n \`✍️ Fully Customizable\`\n\`👀 High Quality Assets\`\n\`😵 Dreamlike designs\``)
            .setThumbnail(message.guild.iconURL() || null)
            .setTimestamp()
            .setFooter({ text: `${message.guild.name}`, iconURL: message.guild.iconURL() || null });

        // Send the embed message with buttons
        const msg = await message.channel.send({ embeds: [embed], components: [row, row3] });

        // Disable buttons after 3 minutes
        setTimeout(() => {
            row.components.forEach(button => button.setDisabled(true));
            row3.components.forEach(button => button.setDisabled(true));
            msg.edit({ embeds: [embed], components: [row, row3] });
        }, 180000);
    }
};
