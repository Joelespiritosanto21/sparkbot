const { Client, MessageEmbed } = require('discord.js');
const db = require("quick.db");

module.exports = {
    name: 'setsuggestions',
    description: "Set a channel for suggestions",
    category: "Settings",
    aliases: ['cc'],
    userPermissions: ["MANAGE_CHANNELS"],
    botPermissions: [],
    emoji: "🛠️",

    /**
     * @param {Client} client
     * @param {Message} message
     * @param {String[]} args
     */
    run: async (client, message, args) => {
        try {
            // Check if a channel ID was provided
            if (!args[0]) {
                return message.reply("Please provide a channel mention or ID.");
            }

            // Get the channel from the mention or ID
            const channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);

            // Check if the channel exists and is valid
            if (!channel || channel.type !== 'GUILD_TEXT') {
                return message.reply("Please provide a valid text channel.");
            }

            // Store the channel ID in the database
            db.set(`suggestions_${message.guild.id}`, channel.id);

            // Send a confirmation message
            message.channel.send(`✅ Done! Suggestions will be sent to ${channel}.`);
        } catch (e) {
            console.error(e);
            message.reply("An error occurred while setting up the suggestions channel.");
        }
    }
};
