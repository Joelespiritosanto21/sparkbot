const { Schema, model } = require('mongoose');

const giveawaySchema = new Schema({
    guildId: { type: String, required: true },
    title: { type: String, required: true },
    winners: { type: Number, required: true },
    prize: { type: String, required: true },
    startDate: { type: Date, default: Date.now },
    endDate: { type: Date, required: true },
    giveawayId: { type: String, required: true, unique: true }, // Add this line
    participants: { type: [String], default: [] }
});

module.exports = model('Giveaway', giveawaySchema);
