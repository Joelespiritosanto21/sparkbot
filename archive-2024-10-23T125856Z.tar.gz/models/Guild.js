const mongoose = require('mongoose');

// Define the schema for the Guild model
const guildSchema = new mongoose.Schema(
    {
        guildId: {
            type: String,
            required: true,
            unique: true, // Ensure each guild has a unique ID
            index: true, // Index for better query performance
        },
        prefix: {
            type: String,
            default: '!', // Default prefix
        },
        commands: {
            type: [String], // Array of command names
            default: [], // Default to an empty array
        },
    },
    {
        timestamps: true, // Automatically manage createdAt and updatedAt fields
        strict: true, // Ensure only the specified fields can be saved
    }
);

// Create the model from the schema
const Guild = mongoose.model('Guild', guildSchema);

// Export the model for use in other files
module.exports = Guild;
